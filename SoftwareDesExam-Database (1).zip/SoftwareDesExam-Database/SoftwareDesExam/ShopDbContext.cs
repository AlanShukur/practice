﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SoftwareDesExam
{
    public class ShopDbContext : DbContext
    {
        public DbSet<Card> Cards => Set<Card>();
        public DbSet<Cart> Carts => Set<Cart>();
        public DbSet<Customer> Customer => Set<Customer>();
        public DbSet<Item> Items => Set<Item>();
        public DbSet<Order> Orders => Set<Order>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(@"Data Source = Resources\clothes_shop.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order>()
                .HasOne(o => o.Customer)
                .WithMany(c => c.Orders)
                .HasForeignKey(o => o.CustomerId)
                .OnDelete(DeleteBehavior.Cascade); 

			modelBuilder.Entity<Card>()
				.HasOne(c => c.Customer)
				.WithMany(cu => cu.CreditCards) 
				.HasForeignKey(c => c.CustomerId)  
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<Item>()
			   .HasOne(i => i.Order)
			   .WithMany(o => o.Items)
			   .HasForeignKey(i => i.OrderId);
		}
    }
}