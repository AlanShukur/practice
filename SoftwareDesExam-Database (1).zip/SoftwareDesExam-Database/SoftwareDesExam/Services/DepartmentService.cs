﻿using SoftwareDesExam.Models;
using System.Collections.Generic;
using System.Linq;

namespace SoftwareDesExam.Services
{
	public class DepartmentService
	{
		// Initialize items in the database if they don't exist
		public void InitializeItems()
		{
			using (var context = new ShopDbContext())
			{
				if (!context.Items.Any()) // Check if the table is empty
				{
					var items = new List<Item>
					{
						new Item("Red Hoodie", 20.99m, 10),
						new Item("Blue Hoodie", 18.99m, 5),
						new Item("Jeans", 25.99m, 15),
						new Item("Shorts", 15.99m, 20)
					};

					context.Items.AddRange(items);
					context.SaveChanges();
				}
			}
		}

		public List<Item> GetItemsByCategory(string category)
		{
			using (var context = new ShopDbContext())
			{
				// Fetch items based on category
				if (category == "Hoodies")
				{
					return context.Items.Where(i => i.Name.Contains("Hoodie")).ToList();
				}
				else if (category == "Pants")
				{
					return context.Items.Where(i => i.Name.Contains("Jeans") || i.Name.Contains("Shorts")).ToList();
				}

				return new List<Item>();
			}
		}

		public List<Item> GetAllItems()
		{
			using (var context = new ShopDbContext())
			{
				return context.Items.ToList();
			}
		}
	}
}
