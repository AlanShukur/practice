﻿using Microsoft.EntityFrameworkCore;
using SoftwareDesExam.Models;
using System.Collections.Generic;
using System.Linq;

namespace SoftwareDesExam.Services
{
	public class CustomerService
	{
		private static List<Customer> customers = new List<Customer>();
		private static Customer? loggedInCustomer; // Holder på innlogget bruker

		public bool Register(Customer customer)
		{
			using (var context = new ShopDbContext())
			{
				// Check if email already exists
				if (context.Customer.Any(c => c.Email.ToLower() == customer.Email.ToLower()))
				{
					return false; // Email is already registered
				}

				context.Customer.Add(customer);
				context.SaveChanges();
				return true;
			}
		}

		public bool IsEmailRegistered(string email)
		{
			// Sjekk om e-posten finnes i listen (ikke case-sensitiv)
			return customers.Any(c => c.Email.ToLower() == email.ToLower());
		}

		public bool Login(string email, string password)
		{
			using (var context = new ShopDbContext())
			{
				// Retrieve customer with their CreditCards included
				var customer = context.Customer
					.Include(c => c.CreditCards) // Load related CreditCards
					.FirstOrDefault(c => c.Email.ToLower() == email.ToLower() && c.Password == password);

				if (customer != null)
				{
					loggedInCustomer = customer; // Store the fully-loaded customer
					return true;
				}

				return false;
			}
		}

		public void Logout()
		{
			loggedInCustomer = null;
		}

		public Customer? GetLoggedInCustomer()
		{
			return loggedInCustomer;
		}
	}
}
