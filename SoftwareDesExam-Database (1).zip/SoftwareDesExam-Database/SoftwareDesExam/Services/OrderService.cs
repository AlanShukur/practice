﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftwareDesExam.Services
{
	public class OrderService
	{
		private readonly DepartmentService _departmentService;

		public OrderService()
		{
			_departmentService = new DepartmentService();
		}

		public void PlaceOrder(Customer customer, List<string> itemNames, string address)
		{
			using (var context = new ShopDbContext())
			{
				// Fetch items based on names from the database
				var selectedItems = context.Items
					.Where(item => itemNames.Contains(item.Name))
					.ToList();

				if (!selectedItems.Any())
				{
					Console.WriteLine("No valid items were selected.");
					return;
				}

				// Prompt for quantity for each item and update stock
				var itemsForOrder = new List<Item>();
				foreach (var item in selectedItems)
				{
					Console.Write($"Enter quantity for {item.Name} (Available: {item.Quantity}): ");
					if (int.TryParse(Console.ReadLine(), out int requestedQuantity) && requestedQuantity > 0)
					{
						if (requestedQuantity > item.Quantity)
						{
							Console.WriteLine($"Not enough stock for {item.Name}. Available: {item.Quantity}");
							return;
						}

						// Update the item's quantity
						item.Quantity -= requestedQuantity;

						// Create a copy for the order with the requested quantity
						var itemForOrder = new Item(item.Name, item.Price, requestedQuantity);
						itemsForOrder.Add(itemForOrder);
					}
					else
					{
						Console.WriteLine("Invalid quantity entered.");
						return;
					}
				}

				// Create a new Order
				var order = new Order
				{
					CustomerId = customer.Id,
					CustomerName = customer.Name,
					Address = address,
					OrderDate = DateTime.Now,
					ReceiptNumber = GenerateReceiptNumber(),
					Items = itemsForOrder,
					TotalPrice = itemsForOrder.Sum(i => i.Price * i.Quantity)
				};

				// Link items to the order
				foreach (var item in itemsForOrder)
				{
					item.Order = order;
				}

				// Add the order and save changes
				context.Orders.Add(order);
				context.SaveChanges();

				Console.WriteLine("Order successfully placed and saved to the database!");
			}
		}

		public List<Order> GetOrders()
		{
			using (var context = new ShopDbContext())
			{
				return context.Orders.ToList();
			}
		}

		private string GenerateReceiptNumber()
		{
			return Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
		}
	}
}
