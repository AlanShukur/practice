﻿using SoftwareDesExam.Views;
using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Services
{
	public class CreditCardService {
		private readonly Random _random = new Random(); // Random instance for generating balances

		public void RegisterCreditCard(Customer customer) {
			if (customer == null) {
				Console.WriteLine("Customer is not logged in. Cannot register a credit card.");
				return;
			}

			var creditCardView = new CreditCardView();
			var newCard = creditCardView.RegisterCard();

			using (var context = new ShopDbContext()) {
				// Check for duplicate card by comparing card numbers
				if (context.Cards.Any(c => c.CardNumber == newCard.CardNumber && c.CustomerId == customer.Id)) {
					Console.WriteLine("This credit card is already registered.");
					Console.WriteLine("Press Enter to return to the main menu...");
					Console.ReadLine();
					return;
				}

				// Set the balance to 5000 instead of random
				newCard.Balance = 5000;

				newCard.CustomerId = customer.Id;

				// Add the new card to the database
				context.Cards.Add(newCard);
				context.SaveChanges();

				// Refresh the customer's credit cards list from the database
				context.Entry(customer).Collection(c => c.CreditCards).Load();

				Console.WriteLine("\nCredit card successfully registered and saved to the database!");
				Console.WriteLine($"Card Info: {newCard.CardType} **** **** **** {newCard.CardNumber.Substring(newCard.CardNumber.Length - 4)}, Balance: {newCard.Balance:C}");
			}

			Console.WriteLine("\nPress Enter to return to the main menu...");
			Console.ReadLine();
		}


		public void DeleteCreditCard(Customer customer) {
			if (customer == null) {
				Console.WriteLine("Customer is not logged in. Cannot delete a credit card.");
				Console.WriteLine("Press Enter to return to the main menu...");
				Console.ReadLine();
				return;
			}

			using (var context = new ShopDbContext()) {
				var cards = context.Cards.Where(c => c.CustomerId == customer.Id).ToList();

				if (!cards.Any()) {
					Console.WriteLine("No credit cards are registered to delete.");
					Console.WriteLine("Press Enter to return to the main menu...");
					Console.ReadLine();
					return;
				}

				Console.WriteLine("Select the credit card you want to delete:");
				for (int i = 0; i < cards.Count; i++) {
					var card = cards[i];
					Console.WriteLine($"{i + 1}. {card.CardType} **** **** **** {card.CardNumber.Substring(card.CardNumber.Length - 4)}");
				}

				Console.Write("\nEnter the number of the card you want to delete: ");
				if (int.TryParse(Console.ReadLine(), out int choice) && choice > 0 && choice <= cards.Count) {
					var selectedCard = cards[choice - 1];
					Console.WriteLine($"Are you sure you want to delete {selectedCard.CardType} **** **** **** {selectedCard.CardNumber.Substring(selectedCard.CardNumber.Length - 4)}? (yes/no)");
					var confirmation = Console.ReadLine()?.ToLower();

					if (confirmation == "yes") {
						context.Cards.Remove(selectedCard);
						context.SaveChanges();
						Console.WriteLine("Credit card deleted successfully from the database.");
					} else {
						Console.WriteLine("Credit card deletion cancelled.");
					}
				} else {
					Console.WriteLine("Invalid choice. No card was deleted.");
				}
			}

			Console.WriteLine("Press Enter to return to the main menu...");
			Console.ReadLine();
		}
	}
}
