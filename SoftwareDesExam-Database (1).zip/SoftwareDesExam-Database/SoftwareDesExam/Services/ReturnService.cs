﻿using SoftwareDesExam.Views;
using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Services
{
    public class ReturnService
    {
        private readonly DepartmentService _departmentService = new DepartmentService();

        public void ProcessReturn(Customer customer, string receiptNumber)
        {
            var order = customer.OrderHistory.FirstOrDefault(o => o.ReceiptNumber == receiptNumber);

            if (order == null)
            {
                new ReturnView().ShowInvalidReceiptMessage();
                return;
            }

            var returnView = new ReturnView();
            returnView.ShowOrderDetails(order);

            var selectedItemIndex = returnView.GetSelectedItemIndex(order.Items);
            if (selectedItemIndex == -1) return;

            var selectedItem = order.Items[selectedItemIndex];
            var returnQuantity = returnView.GetReturnQuantity(selectedItem);
            if (returnQuantity == -1) return;

            // Process refund
            RefundItem(customer, selectedItem, returnQuantity);

            // Update inventory
            UpdateStoreInventory(selectedItem, returnQuantity);

            // Update the order
            selectedItem.Quantity -= returnQuantity;
            if (selectedItem.Quantity == 0)
            {
                order.Items.Remove(selectedItem);
            }

            // Display success messages
            returnView.ShowReturnSuccess(returnQuantity, selectedItem.Name);
        }

        public void RefundItem(Customer customer, Item returnedItem, int returnQuantity)
        {
            decimal refundAmount = returnedItem.Price * returnQuantity;

            // Select a credit card for refund
            var returnView = new ReturnView();
            Console.WriteLine("Select a credit card to refund the money to:");
            for (int i = 0; i < customer.CreditCards.Count; i++)
            {
                var card = customer.CreditCards[i];
                Console.WriteLine($"{i + 1}. {card.CardType} **** **** **** {card.CardNumber.Substring(card.CardNumber.Length - 4)}, Balance: {card.Balance:C}");
            }

            Console.Write("Enter the number of the credit card you want to refund the money to: ");
            if (int.TryParse(Console.ReadLine(), out int cardChoice) && cardChoice > 0 && cardChoice <= customer.CreditCards.Count)
            {
                var selectedCard = customer.CreditCards[cardChoice - 1];
                selectedCard.Balance += refundAmount;
                returnView.ShowRefundSuccess(refundAmount, selectedCard.CardType, selectedCard.CardNumber);
            }
            else
            {
                Console.WriteLine("Invalid card selection. Refund cancelled.");
            }
        }

        public void UpdateStoreInventory(Item returnedItem, int returnQuantity)
        {
            // Find the item in the department and update its quantity
            var departmentItems = _departmentService.GetAllItems(); // Implement this method to return all items from all departments
            var storeItem = departmentItems.FirstOrDefault(i => i.Name == returnedItem.Name);

            if (storeItem != null)
            {
                storeItem.Quantity += returnQuantity;
                new ReturnView().ShowInventoryUpdate(returnedItem.Name, returnQuantity);
            }
        }
    }
}
