﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Services
{
    public class CartService
    {
        private static Cart _cart = new Cart();

		public void AddToCart(Item storeItem, int quantity)
		{
			using (var context = new ShopDbContext())
			{
				// Fetch the item from the database
				var dbItem = context.Items.FirstOrDefault(i => i.Id == storeItem.Id);
				if (dbItem == null)
				{
					Console.WriteLine($"Item '{storeItem.Name}' not found in the database.");
					return;
				}

				// Check if enough stock is available
				if (quantity > dbItem.Quantity)
				{
					Console.WriteLine($"Not enough stock for {dbItem.Name}. Available: {dbItem.Quantity}.");
					return;
				}

				// Update the stock in the database
				dbItem.Quantity -= quantity;

				// Add the item to the cart (local copy)
				var cartItem = _cart.Items.FirstOrDefault(i => i.Name == dbItem.Name);
				if (cartItem != null)
				{
					cartItem.Quantity += quantity;
				}
				else
				{
					_cart.Items.Add(new Item(dbItem.Name, dbItem.Price, quantity));
				}

				// Save changes to the database
				context.SaveChanges();

				Console.WriteLine($"Added {quantity} x {dbItem.Name} to the cart. Remaining stock: {dbItem.Quantity}.");
			}
		}

		public Cart GetCart()
        {
            return _cart;
        }

        public void ClearCart()
        {
            _cart.ClearCart();
        }
    }
}
