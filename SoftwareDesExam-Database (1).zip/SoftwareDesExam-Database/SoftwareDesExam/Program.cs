﻿using SoftwareDesExam.Controllers;
using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using SoftwareDesExam.Views;

namespace SoftwareDesExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
			// CreateTestData();
			// DisplayItems();
			var departmentService = new DepartmentService();
			departmentService.InitializeItems();

			var mainMenuController = new MainMenuController();
            mainMenuController.ShowMainMenu();

		}

        static void DisplayItems()
        {
            using ShopDbContext db = new();

            List<Item> items = db.Items.ToList();
            items.ForEach(item => Console.WriteLine(item.Name, item.Price, item.Quantity));

            Console.WriteLine("----------------------");
        }

        static void CreateTestData()
        {
            List<Item> items = new()
            {
                new Item ( "test_Traicksuit", 124.99m, 10),
				new Item ( "tester_shorts", 33.99m, 3),
				new Item ( "bUKSEEEE", 283m, 1)
			};

            using ShopDbContext db = new();

			foreach (var item in items)
			{
				bool exists = db.Items.Any(i => i.Name == item.Name);

				if (!exists)
				{
					db.Items.Add(item);
				}
			}

			db.SaveChanges();
        }
    }
}
