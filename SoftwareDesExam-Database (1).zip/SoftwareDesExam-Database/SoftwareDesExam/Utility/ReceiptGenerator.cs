﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Utility
{
    internal class ReceiptGenerator
    {
        private static readonly Random Random = new Random();

        public static string GenerateReceipt()
        {
            return $"{Random.Next(100000, 999999)}{Random.Next(100000, 999999)}";
        }
    }
}
