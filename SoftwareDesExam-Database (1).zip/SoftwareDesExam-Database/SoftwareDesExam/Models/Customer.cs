﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Models
{
	public class Customer {
		public int Id { get; set; }
		public string Name { get; set; } = string.Empty;
		public string Address { get; set; } = string.Empty;
		public string Email { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;

		// Navigation Properties
		public ICollection<Order> Orders { get; set; }
		public List<Card> CreditCards { get; set; } = new List<Card>(); // Support multiple cards
		public List<Order> OrderHistory { get; set; } = new List<Order>(); // Support order history

		public override string ToString() {
			return $"Name: {Name}, Address: {Address}, Email: {Email}, Credit Cards: {CreditCards.Count}, Orders: {OrderHistory.Count}";
		}
	}
}
