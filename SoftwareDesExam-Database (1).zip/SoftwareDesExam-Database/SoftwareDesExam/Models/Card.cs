﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Models {
	public class Card {
		public int Id { get; set; }
		public string CardNumber { get; set; } = string.Empty;
		public string ExpiryDate { get; set; } = string.Empty;
		public string CardType { get; set; } = string.Empty;
		public string CVV { get; set; } = string.Empty;
		public decimal Balance { get; set; } // New property for balance

		// Foreign Key
		public int CustomerId { get; set; } // Non-nullable foreign key

		// Navigation Property
		public Customer Customer { get; set; }

		public override string ToString() {
			return $"{CardType} **** **** **** {CardNumber.Substring(CardNumber.Length - 4)}, Balance: {Balance:C}";
		}
	}
}
