﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Models
{
    public class Cart
    {
        public int Id { get; set; }
        public List<Item> Items { get; private set; } = new List<Item>();

        public decimal GetTotalPrice()
        {
            return Items.Sum(item => item.Price * item.Quantity);
        }

        public void AddItem(Item item)
        {
            Items.Add(item);
        }

        public void ClearCart()
        {
            Items.Clear();
        }

        public override string ToString()
        {
            if (Items.Count == 0) return "Cart is empty.";
            return string.Join("\n", Items.Select(item => $"{item.Name} x{item.Quantity}, Total: {item.Price * item.Quantity:C}"));
        }
    }
}
