﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Models
{
    public class Order
    {
        public int Id { get; set; }
        public Customer Customer { get; set; }
        public int CustomerId { get; set; }
        public string? ReceiptNumber { get; set; }
        public List<Item> Items { get; set; } = new List<Item>();
        public string CustomerName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; } = DateTime.Now;

        // TotalPrice is now a normal field
        public decimal TotalPrice { get; set; }

        public override string ToString()
        {
            string itemsDescription = string.Join(", ", Items.Select(item => $"{item.Name} (x{item.Quantity}, {item.Price:C})"));
            return $"Receipt: {ReceiptNumber}\nOrder Date: {OrderDate}\nCustomer: {CustomerName}, Address: {Address}\nItems: {itemsDescription}\nTotal: {TotalPrice:C}";
        }
    }
}
