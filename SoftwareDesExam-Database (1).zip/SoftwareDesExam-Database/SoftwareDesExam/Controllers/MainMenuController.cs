﻿using SoftwareDesExam.Controllers;
using SoftwareDesExam.Services;
using SoftwareDesExam.Views;

namespace SoftwareDesExam.Controllers
{
    public class MainMenuController
    {
        private readonly CustomerController _customerController = new CustomerController();

        public void ShowMainMenu()
        {
            while (true)
            {
                try
                {
                    Console.Clear();
                    var loggedInCustomer = _customerController.GetLoggedInCustomer(); // Fetch the logged-in customer here
                    var mainMenuView = new MainMenuView();
                    var userChoice = mainMenuView.Show(loggedInCustomer);

                    switch (userChoice)
                    {
                        case "1": // Departments
                            new DepartmentController().ShowDepartments();
                            break;
                        case "2": // View Cart
                            new CartController().ShowCart();
                            break;
                        case "3": // View Orders
                            var orderController = new OrderController();
                            orderController.ShowOrders(loggedInCustomer); // The controller handles null checks and logic
                            break;
                        case "4": // Wallet
                            new CreditCardController().ManageWallet(loggedInCustomer); // The controller handles null checks and logic
                            break;
                        case "5": // Return Product
                            if (loggedInCustomer != null)
                            {
                                new ReturnController().HandleReturn(loggedInCustomer); // The controller handles null checks and logic
                            }
                            else
                            {
                                Console.WriteLine("You must be logged in to return products.");
                                Console.WriteLine("Press Enter to return to the main menu...");
                                Console.ReadLine();
                            }
                            break;
                        case "6": // Log In
                            _customerController.Login();
                            break;
                        case "7": // Register
                            _customerController.Register();
                            Console.WriteLine("Thank you for registering! Please log in to continue.");
                            Console.WriteLine("Press Enter to return to the main menu...");
                            Console.ReadLine();
                            break;
                        case "8": // Exit
                            mainMenuView.Exit();
                            break;
                        default:
                            mainMenuView.InvalidChoice();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                    Console.WriteLine("Press Enter to continue...");
                    Console.ReadLine();
                }
            }
        }
    }
}
