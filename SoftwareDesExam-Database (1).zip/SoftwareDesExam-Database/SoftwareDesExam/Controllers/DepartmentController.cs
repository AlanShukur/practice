﻿using SoftwareDesExam.Views;
using SoftwareDesExam.Models;
using SoftwareDesExam.Services;

namespace SoftwareDesExam.Controllers
{
    public class DepartmentController
    {
        private readonly CartService _cartService = new CartService();
        private readonly DepartmentService _departmentService = new DepartmentService();

		public void ShowDepartments()
		{
			var departmentView = new DepartmentView();
			var userChoice = departmentView.Show();

			switch (userChoice)
			{
				case "1":
					ShowItems("Hoodies", _departmentService.GetItemsByCategory("Hoodies"));
					break;
				case "2":
					ShowItems("Pants", _departmentService.GetItemsByCategory("Pants"));
					break;
				case "3":
					return; // Back to Main Menu
				default:
					Console.WriteLine("Invalid choice. Press Enter to try again...");
					Console.ReadLine();
					ShowDepartments();
					break;
			}
		}


		private void ShowItems(string department, List<Item> items)
		{
			var dbItems = _departmentService.GetItemsByCategory(department); // Fetch from DB
			Console.Clear();
			Console.WriteLine($"Available items in {department}:");

			for (int i = 0; i < dbItems.Count; i++)
			{
				Console.WriteLine($"{i + 1}. {dbItems[i]}");
			}

			Console.WriteLine($"{dbItems.Count + 1}. Back to Departments");
			Console.Write("Choose an item to add to your cart: ");

			if (int.TryParse(Console.ReadLine(), out int itemChoice) &&
				itemChoice > 0 && itemChoice <= dbItems.Count)
			{
				var selectedItem = dbItems[itemChoice - 1];

				Console.Write($"Enter the quantity of {selectedItem.Name} you want to purchase: ");
				if (int.TryParse(Console.ReadLine(), out int quantity) && quantity > 0)
				{
					if (selectedItem.Quantity >= quantity)
					{
						_cartService.AddToCart(selectedItem, quantity);
						Console.WriteLine($"{quantity} x {selectedItem.Name} added to the cart.");
					}
					else
					{
						Console.WriteLine($"Only {selectedItem.Quantity} of {selectedItem.Name} are available.");
					}
				}
				else
				{
					Console.WriteLine("Invalid quantity. Please try again.");
				}

				Console.WriteLine("Press Enter to return to the department selection menu...");
				Console.ReadLine();
				ShowItems(department, items);
			}
			else if (itemChoice == dbItems.Count + 1)
			{
				ShowDepartments();
			}
			else
			{
				Console.WriteLine("Invalid choice. Press Enter to try again...");
				Console.ReadLine();
				ShowItems(department, items);
			}
		}
	}
}
