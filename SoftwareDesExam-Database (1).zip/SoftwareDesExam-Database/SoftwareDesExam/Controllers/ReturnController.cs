﻿using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using SoftwareDesExam.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Controllers
{
    public class ReturnController
    {
        private readonly ReturnService _returnService = new ReturnService();
        private readonly ReturnView _returnView = new ReturnView();

        public void HandleReturn(Customer customer)
        {
            if (customer == null)
            {
                _returnView.ShowNoOrdersMessage();
                _returnView.Pause();
                return;
            }

            var receiptNumber = _returnView.GetReceiptNumber();

            var order = customer.OrderHistory.FirstOrDefault(o => o.ReceiptNumber == receiptNumber);
            if (order == null)
            {
                _returnView.ShowInvalidReceiptMessage();
                _returnView.Pause();
                return;
            }

            _returnView.ShowOrderDetails(order);

            var selectedItemIndex = _returnView.GetSelectedItemIndex(order.Items);
            if (selectedItemIndex == -1)
            {
                _returnView.Pause();
                return;
            }

            var selectedItem = order.Items[selectedItemIndex];
            var returnQuantity = _returnView.GetReturnQuantity(selectedItem);
            if (returnQuantity == -1)
            {
                _returnView.Pause();
                return;
            }

            // Process the return
            _returnService.RefundItem(customer, selectedItem, returnQuantity);
            _returnService.UpdateStoreInventory(selectedItem, returnQuantity);

            // Update the order
            selectedItem.Quantity -= returnQuantity;
            if (selectedItem.Quantity == 0)
            {
                order.Items.Remove(selectedItem);
            }

            _returnView.ShowReturnSuccess(returnQuantity, selectedItem.Name);
            _returnView.Pause();
        }
    }
}
