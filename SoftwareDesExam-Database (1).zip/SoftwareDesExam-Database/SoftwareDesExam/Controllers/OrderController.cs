﻿using SoftwareDesExam.Views;
using SoftwareDesExam.Models;
using SoftwareDesExam.Services;

namespace SoftwareDesExam.Controllers
{
    public class OrderController
    {
        private readonly ReturnService _returnService = new ReturnService();

		public void ShowOrders(Customer customer)
		{
			if (customer == null)
			{
				Console.WriteLine("You must be logged in to view your orders.");
				return;
			}

			using (var context = new ShopDbContext())
			{
				// Load orders for the logged-in customer
				var orders = context.Orders
									.Where(o => o.CustomerId == customer.Id)
									.ToList();

				if (!orders.Any())
				{
					Console.WriteLine("You have no previous orders.");
					return;
				}

				// Display orders
				Console.WriteLine("Your Order History:");
				foreach (var order in orders)
				{
					Console.WriteLine("----------------------------------------");
					Console.WriteLine(order);
				}
				Console.WriteLine("----------------------------------------");
			}

			Console.WriteLine("Press Enter to return to the main menu...");
			Console.ReadLine();
		}
	}
}
