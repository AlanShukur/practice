﻿using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using SoftwareDesExam.Views;
using System;

namespace SoftwareDesExam.Controllers
{
    public class CustomerController
    {
        private readonly CustomerService _customerService = new CustomerService();
        private readonly CustomerView _customerView = new CustomerView();

        public void Register()
        {
            Console.WriteLine("Starting registration...");

            // Hent kundeinformasjon fra CustomerView
            var customer = _customerView.GetCustomerDetails();

            // Forsøk å registrere brukeren
            if (_customerService.Register(customer))
            {
                Console.WriteLine("Registration successful! You can now log in.");
                Console.WriteLine("Press Enter to return to the main menu...");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Registration failed. Email already in use.");
                Console.WriteLine("Press Enter to try again...");
                Console.ReadLine();
            }
        }

        public void Login()
        {
            Console.WriteLine("Starting login...");

            string email = string.Empty;
            string password = string.Empty;

            // Validering for e-post
            while (string.IsNullOrWhiteSpace(email))
            {
                Console.Write("Enter Email: ");
                email = Console.ReadLine()?.Trim().ToLower();

                if (string.IsNullOrWhiteSpace(email))
                {
                    Console.WriteLine("Email cannot be empty. Please enter your email.");
                }
            }

            // Validering for passord
            while (string.IsNullOrWhiteSpace(password))
            {
                Console.Write("Enter Password: ");
                password = Console.ReadLine()?.Trim();

                if (string.IsNullOrWhiteSpace(password))
                {
                    Console.WriteLine("Password cannot be empty. Please enter your password.");
                }
            }

            // Forsøk å logge inn
            if (_customerService.Login(email, password))
            {
                Console.WriteLine($"Login successful! Welcome back, {_customerService.GetLoggedInCustomer()?.Name}.");
            }
            else
            {
                Console.WriteLine("Login failed. Invalid email or password.");
            }
        }

        public Customer? GetLoggedInCustomer()
        {
            return _customerService.GetLoggedInCustomer();
        }

        public void Logout()
        {
            if (_customerService.GetLoggedInCustomer() != null)
            {
                _customerService.Logout();
                Console.WriteLine("You have been logged out.");
            }
            else
            {
                Console.WriteLine("No user is currently logged in.");
            }
        }
    }
}
