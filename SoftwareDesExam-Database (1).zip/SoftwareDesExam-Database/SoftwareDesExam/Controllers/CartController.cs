﻿using SoftwareDesExam.Views;
using SoftwareDesExam.Models;
using SoftwareDesExam.Controllers;
using SoftwareDesExam.Services;

namespace SoftwareDesExam.Controllers
{
    public class CartController
    {
        private readonly CartService _cartService = new CartService();

        public void ShowCart()
        {
            var loggedInCustomer = new CustomerController().GetLoggedInCustomer();
            if (loggedInCustomer == null)
            {
                Console.WriteLine("You must be logged in to view your cart.");
                return;
            }

            var cartView = new CartView();
            var cart = _cartService.GetCart();
            var cartItems = cart.Items; // Hent varer fra Cart-objektet
            var userChoice = cartView.Show(cartItems);

            switch (userChoice)
            {
                case "1":
                    if (cartItems.Count > 0)
                    {
                        new CheckoutView().Checkout(_cartService, loggedInCustomer); // Send begge argumentene
                    }
                    else
                    {
                        Console.WriteLine("Your cart is empty. Cannot proceed to checkout.");
                        Console.WriteLine("Press Enter to go back.");
                        Console.ReadLine();
                    }
                    break;
                case "2":
                    return;
                default:
                    Console.WriteLine("Invalid choice. Press Enter to try again.");
                    Console.ReadLine();
                    ShowCart();
                    break;
            }
        }
    }
}
