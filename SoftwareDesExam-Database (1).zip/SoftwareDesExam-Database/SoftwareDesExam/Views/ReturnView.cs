﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Views
{
    public class ReturnView
    {
        public string GetReceiptNumber()
        {
            Console.Write("Enter the receipt number of the order you want to return a product from: ");
            return Console.ReadLine() ?? string.Empty;
        }

        public void ShowOrderDetails(Order order)
        {
            Console.WriteLine($"Order found: Receipt #{order.ReceiptNumber}");
            Console.WriteLine("Items in the order:");

            for (int i = 0; i < order.Items.Count; i++)
            {
                var item = order.Items[i];
                Console.WriteLine($"{i + 1}. {item.Name} x{item.Quantity}, Total: {item.Price * item.Quantity:C}");
            }
        }

        public int GetSelectedItemIndex(List<Item> items)
        {
            Console.Write("Select the item you want to return: ");
            if (int.TryParse(Console.ReadLine(), out int itemChoice) && itemChoice > 0 && itemChoice <= items.Count)
            {
                return itemChoice - 1; // Return zero-based index
            }

            Console.WriteLine("Invalid choice. Returning to the main menu...");
            return -1; // Indicate an invalid selection
        }

        public int GetReturnQuantity(Item selectedItem)
        {
            Console.Write($"Enter the quantity of {selectedItem.Name} you want to return: ");
            if (int.TryParse(Console.ReadLine(), out int returnQuantity) && returnQuantity > 0 && returnQuantity <= selectedItem.Quantity)
            {
                return returnQuantity;
            }

            Console.WriteLine("Invalid quantity. Returning to the main menu...");
            return -1; // Indicate an invalid quantity
        }

        public void ShowRefundSuccess(decimal refundAmount, string cardType, string cardNumber)
        {
            Console.WriteLine($"Refund successful! {refundAmount:C} has been added to your {cardType} **** **** **** {cardNumber.Substring(cardNumber.Length - 4)}.");
        }

        public void ShowInventoryUpdate(string itemName, int quantity)
        {
            Console.WriteLine($"Inventory updated: {quantity} x {itemName} added back to stock.");
        }

        public void ShowReturnSuccess(int quantity, string itemName)
        {
            Console.WriteLine($"{quantity} x {itemName} returned successfully.");
        }

        public void ShowInvalidReceiptMessage()
        {
            Console.WriteLine("Invalid receipt number. Please try again.");
        }

        public void ShowNoOrdersMessage()
        {
            Console.WriteLine("You have no orders to return products from.");
        }

        public void Pause()
        {
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
