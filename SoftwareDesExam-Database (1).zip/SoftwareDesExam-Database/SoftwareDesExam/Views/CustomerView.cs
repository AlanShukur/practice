﻿using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using System;

namespace SoftwareDesExam.Views
{
    public class CustomerView
    {
        private readonly CustomerService customerService = new CustomerService();

        public Customer GetCustomerDetails()
        {
            string name = string.Empty;
            string address = string.Empty;
            string email = string.Empty;
            string password = string.Empty;

            // Name
            while (string.IsNullOrWhiteSpace(name))
            {
                Console.Write("Enter Name: ");
                name = Console.ReadLine()?.Trim();

                if (string.IsNullOrWhiteSpace(name))
                {
                    Console.WriteLine("Name cannot be empty. Please enter your name.");
                }
            }

            // Address
            while (string.IsNullOrWhiteSpace(address))
            {
                Console.Write("Enter Address: ");
                address = Console.ReadLine()?.Trim();

                if (string.IsNullOrWhiteSpace(address))
                {
                    Console.WriteLine("Address cannot be empty. Please enter your address.");
                }
            }

            // Email
            while (string.IsNullOrWhiteSpace(email))
            {
                Console.Write("Enter Email: ");
                email = Console.ReadLine()?.Trim().ToLower(); // Gjør e-posten små bokstaver

                if (string.IsNullOrWhiteSpace(email))
                {
                    Console.WriteLine("Email cannot be empty. Please enter your email.");
                }
                else if (!email.Contains("@"))
                {
                    Console.WriteLine("Invalid email format. Email must contain '@'.");
                    email = string.Empty; // Tømmer e-postfeltet for ny input
                }
                else if (customerService.IsEmailRegistered(email))
                {
                    Console.WriteLine("This email is already in use. Please try a different email.");
                    email = string.Empty; // Tømmer e-postfeltet for ny input
                }
            }

            // Password
            while (string.IsNullOrWhiteSpace(password))
            {
                Console.Write("Enter Password: ");
                password = Console.ReadLine()?.Trim();

                if (string.IsNullOrWhiteSpace(password))
                {
                    Console.WriteLine("Password cannot be empty. Please enter your password.");
                }
            }

            Console.WriteLine("User registered successfully!");

            return new Customer
            {
                Name = name,
                Address = address,
                Email = email,
                Password = password
            };
        }
    }
}
