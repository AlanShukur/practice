﻿using SoftwareDesExam.Services;
using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Views
{
    public class DepartmentView
    {
        public string Show()
        {
            Console.Clear();
            Console.WriteLine("Choose a department:");
            Console.WriteLine("1. Hoodies");
            Console.WriteLine("2. Pants");
            Console.WriteLine("3. Back to Main Menu");
            Console.Write("Enter your choice: ");
            return Console.ReadLine() ?? "0";
        }

        public Item? ShowItems(List<Item> items)
        {
            Console.Clear();
            for (int i = 0; i < items.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {items[i]}");
            }
            Console.WriteLine("Enter the number to add to cart or 0 to go back:");

            if (int.TryParse(Console.ReadLine(), out int choice) && choice > 0 && choice <= items.Count)
            {
                return items[choice - 1];
            }

            return null; // Go back
        }

        public void InvalidChoice()
        {
            Console.WriteLine("Invalid choice. Press Enter to try again.");
            Console.ReadLine();
        }
    }
}
