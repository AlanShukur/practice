﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Views
{
    public class MainMenuView
    {
        public string Show(Customer? loggedInCustomer)
        {

            if (loggedInCustomer != null)
            {
                Console.WriteLine($"Logged in as: {loggedInCustomer.Name}");
            }
            else
            {
                Console.WriteLine("Not logged in ");
            }
            Console.WriteLine("WELCOME TO THE CLOTHES SHOP!");
            Console.WriteLine("1. Select Department");
            Console.WriteLine("2. View Cart");
            Console.WriteLine("3. View Orders");
            Console.WriteLine("4. Wallet");
            Console.WriteLine("5. Return products");
            Console.WriteLine("6. Log in");
            Console.WriteLine("7. Register");
            Console.WriteLine("8. Exit");
            Console.Write("Choose an option: ");
            return Console.ReadLine() ?? "0"; // Default to "0" if input is null
        }

        public void Exit()
        {
            Console.WriteLine("Thank you for visiting!");
            Environment.Exit(0);
        }

        public void InvalidChoice()
        {
            Console.WriteLine("Invalid choice. Press Enter to try again.");
            Console.ReadLine();
        }
    }
}
