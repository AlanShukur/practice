﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareDesExam.Views
{
    public class CreditCardView
    {
        private readonly Random random = new Random();

        public Card RegisterCard()
        {
            Console.Clear();
            Console.WriteLine("Starting credit card registration...");

            string cardNumber;
            do
            {
                Console.Write("Enter Card Number (16 digits): ");
                cardNumber = Console.ReadLine() ?? string.Empty;
            } while (string.IsNullOrEmpty(cardNumber) || cardNumber.Length != 16 || !cardNumber.All(char.IsDigit));

            Console.Write("Enter Expiry Date (MM/YY): ");
            var expiryDate = Console.ReadLine() ?? string.Empty;

            Console.Write("Enter Card Type (Visa/Mastercard): ");
            var cardType = Console.ReadLine() ?? string.Empty;

            string cvv;
            do
            {
                Console.Write("Enter CVV (3 digits): ");
                cvv = Console.ReadLine() ?? string.Empty;
            } while (string.IsNullOrEmpty(cvv) || cvv.Length != 3 || !cvv.All(char.IsDigit));

            // Assign a random balance between 500 and 5000
            var initialBalance = random.Next(500, 5001);

            return new Card
            {
                CardNumber = cardNumber,
                ExpiryDate = expiryDate,
                CardType = cardType,
                CVV = cvv,
                Balance = initialBalance
            };
        }
    }
}
