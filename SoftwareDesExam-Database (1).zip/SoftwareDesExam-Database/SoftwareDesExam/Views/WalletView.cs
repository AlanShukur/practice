﻿using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using System;
using System.Linq;

namespace SoftwareDesExam.Views
{
	public class WalletView
	{
		private readonly CreditCardService creditCardService = new CreditCardService();

		public void Show(Customer customer)
		{
			if (customer == null)
			{
				Console.WriteLine("You must be logged in to access your wallet.");
				Console.WriteLine("Press Enter to return to the main menu...");
				Console.ReadLine();
				return;
			}

			while (true)
			{
				// Reload credit cards from the database
				using (var context = new ShopDbContext())
				{
					context.Entry(customer).Collection(c => c.CreditCards).Load();
				}

				Console.Clear();
				Console.WriteLine("Your Wallet:");

				if (!customer.CreditCards.Any())
				{
					Console.WriteLine("No credit cards registered.");
				}
				else
				{
					for (int i = 0; i < customer.CreditCards.Count; i++)
					{
						var card = customer.CreditCards[i];
						Console.WriteLine($"{i + 1}. {card.CardType} **** **** **** {card.CardNumber.Substring(CardNumber.Length - 4)}, Balance: {card.Balance:C}");
					}
				}

				Console.WriteLine("\nOptions:");
				Console.WriteLine("1. Register a new card");
				Console.WriteLine("2. Delete a card");
				Console.WriteLine("3. Back to Main Menu");
				Console.Write("Choose an option: ");

				var choice = Console.ReadLine();
				switch (choice)
				{
					case "1":
						creditCardService.RegisterCreditCard(customer);
						break;
					case "2":
						creditCardService.DeleteCreditCard(customer);
						break;
					case "3":
						return; // Exit the wallet view
					default:
						Console.WriteLine("Invalid choice. Press Enter to try again...");
						Console.ReadLine();
						break;
				}
			}
		}
	}
}
