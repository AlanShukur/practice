﻿using SoftwareDesExam.Models;
using SoftwareDesExam.Services;
using SoftwareDesExam.Utility;
using System;

namespace SoftwareDesExam.Views
{
    public class CheckoutView
    {
		public void Checkout(CartService cartService, Customer customer)
		{
			var cart = cartService.GetCart();

			if (customer == null)
			{
				Console.WriteLine("You must be logged in to proceed to checkout.");
				Console.WriteLine("Press Enter to return to the main menu...");
				Console.ReadLine();
				return;
			}

			if (cart.Items.Count == 0)
			{
				Console.WriteLine("Your cart is empty. Cannot proceed to checkout.");
				Console.WriteLine("Press Enter to return to the main menu...");
				Console.ReadLine();
				return;
			}

			Console.WriteLine("Proceeding to Checkout:");
			foreach (var item in cart.Items)
			{
				Console.WriteLine($"- {item.Name} x{item.Quantity}, Total: {item.Price * item.Quantity:C}");
			}

			Console.WriteLine($"Customer: {customer.Name}, Address: {customer.Address}");

			if (!customer.CreditCards.Any())
			{
				Console.WriteLine("No credit cards registered. Please register a credit card before proceeding to checkout.");
				Console.WriteLine("Press Enter to return to the main menu...");
				Console.ReadLine();
				return;
			}

			// Select a credit card for payment
			Console.WriteLine("Select a credit card to use for payment:");
			for (int i = 0; i < customer.CreditCards.Count; i++)
			{
				var card = customer.CreditCards[i];
				Console.WriteLine($"{i + 1}. {card.CardType} **** **** **** {card.CardNumber.Substring(card.CardNumber.Length - 4)}, Balance: {card.Balance:C}");
			}

			Console.Write("Enter the number of the credit card you want to use: ");
			if (int.TryParse(Console.ReadLine(), out int choice) && choice > 0 && choice <= customer.CreditCards.Count)
			{
				var selectedCard = customer.CreditCards[choice - 1];
				decimal totalPrice = cart.GetTotalPrice();

				if (selectedCard.Balance < totalPrice)
				{
					Console.WriteLine("Insufficient balance on the selected card. Please try another card or add funds.");
					Console.WriteLine("Press Enter to return to the main menu...");
					Console.ReadLine();
					return;
				}

				using (var context = new ShopDbContext())
				{
					// Deduct the card balance
					selectedCard.Balance -= totalPrice;

					// Create the order
					var order = new Order
					{
						ReceiptNumber = ReceiptGenerator.GenerateReceipt(),
						Items = cart.Items.Select(i => new Item(i.Name, i.Price, i.Quantity)).ToList(),
						CustomerId = customer.Id, // Link the order to the customer
						CustomerName = customer.Name,
						Address = customer.Address,
						OrderDate = DateTime.Now,
						TotalPrice = totalPrice
					};

					// Save the order and updated card balance to the database
					context.Attach(customer); // Attach the customer
					context.Orders.Add(order);
					context.Update(selectedCard); // Update the card's balance

					context.SaveChanges(); // Persist changes
				}

				Console.WriteLine("\nPayment successful!");
				Console.WriteLine($"Receipt Number: {ReceiptGenerator.GenerateReceipt()}");
				Console.WriteLine($"New Card Balance: {selectedCard.Balance:C}");

				cartService.ClearCart();
			}
			else
			{
				Console.WriteLine("Invalid card selection. Returning to the main menu...");
			}

			Console.WriteLine("Press Enter to return to the main menu...");
			Console.ReadLine();
		}
	}
}
