﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;

namespace SoftwareDesExam.Views
{
    public class CartView
    {
        public string Show(List<Item> cartItems)
        {
            Console.Clear();
            Console.WriteLine("Your Cart:");

            if (cartItems.Count == 0)
            {
                Console.WriteLine("Your cart is empty.");
            }
            else
            {
                foreach (var item in cartItems)
                {
                    Console.WriteLine($"- {item.Name} x{item.Quantity}, Total: {item.Price * item.Quantity:C}");
                }
            }

            Console.WriteLine("\nOptions:");
            Console.WriteLine("1. Proceed to Checkout");
            Console.WriteLine("2. Back to Main Menu");
            Console.Write("Enter your choice: ");

            return Console.ReadLine() ?? "0";
        }
    }
}
