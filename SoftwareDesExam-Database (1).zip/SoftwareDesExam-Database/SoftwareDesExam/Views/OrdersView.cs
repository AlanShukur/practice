﻿using SoftwareDesExam.Models;
using System;
using System.Collections.Generic;

namespace SoftwareDesExam.Views
{
    public class OrdersView
    {
        public void Show(List<Order> orders)
        {
            Console.Clear();
            Console.WriteLine("Your Orders:");

            if (orders.Count == 0)
            {
                Console.WriteLine("You have no past orders.");
            }
            else
            {
                for (int i = 0; i < orders.Count; i++)
                {
                    Console.WriteLine($"Order {i + 1}:");
                    Console.WriteLine(orders[i]);
                    Console.WriteLine(new string('-', 20));
                }
            }

            Console.WriteLine("\nPress Enter to return to the main menu.");
            Console.ReadLine();
        }
    }
}
